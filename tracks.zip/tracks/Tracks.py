import xml.etree.ElementTree as et
import sqlite3

con = sqlite3.connect('sqlite.db')
cur = con.cursor()

cur.executescript('''
DROP TABLE IF EXISTS Artist;
DROP TABLE IF EXISTS Album;
DROP TABLE IF EXISTS Track;

CREATE TABLE Artist (
    id  INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT UNIQUE,
    name    TEXT UNIQUE
);

CREATE TABLE Album (
    id  INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT UNIQUE,
    artist_id  INTEGER,
    title   TEXT UNIQUE
);

CREATE TABLE Track (
    id  INTEGER NOT NULL PRIMARY KEY
        AUTOINCREMENT UNIQUE,
    title TEXT  UNIQUE,
    album_id  INTEGER,
    len INTEGER,
    rating INTEGER,
    count INTEGER
);
''')

fname = input('Enter file name: ')
if len(fname) < 1:
    fname = 'Library.xml'

data = et.parse(fname)
all = data.findall('dict/dict/dict')

print('Dict count: ',len(all))

def lookup(d, key):
    found = False
    for child in d:
        if found : return child.text
        if child.tag == 'key' and child.text == key :
            found = True
    return None

for i in all:
    if lookup(i,'Track ID') is None:
        continue
    name = lookup(i, 'Name')
    artist = lookup(i, 'Artist')
    album = lookup(i, 'Album')
    count = lookup(i, 'Play Count')
    rating = lookup(i, 'Rating')
    length = lookup(i, 'Total Time')

    if name is None or artist is None or album is None or count is None or rating is None or length is None:
        continue

    cur.execute('''INSERT OR IGNORE INTO Artist(name)  values(?)''',(artist,))
    cur.execute('''SELECT id FROM Artist WHERE NAME = ?''',(artist,))
    artist_id = cur.fetchone()[0]

    cur.execute('''INSERT OR IGNORE INTO Album(title,artist_id) values(?,?)''',(album,artist_id))
    cur.execute('''SELECT id FROM Album WHERE title = ?''',(album,))
    album_id = cur.fetchone()[0]

    cur.execute('''INSERT OR REPLACE INTO Track(title, album_id, len, rating, count) VALUES ( ?, ?, ?, ?, ? )''',
        ( name, album_id, length, rating, count ) )

con.commit()

for i in cur.execute('''SELECT name FROM Artist'''):
    print(str(i[0]))
