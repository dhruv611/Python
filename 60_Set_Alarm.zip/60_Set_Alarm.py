import sched as s
import time as t
import winsound as ws

def setAlarm(time1,msg):
    s1 = s.scheduler(t.time,t.sleep)
    s1.enter(int(time1),1,print,argument = (msg,))
    s1.enter(int(time1),1,ws.PlaySound, argument = ('TestSound2.wav',ws.SND_FILENAME))
    s1.run()

def main():
        time1 = input('Enter time for alarm in sec: ')
        msg = input('Enter message to be displayed: ')
        if time1.isdigit():
                setAlarm(time1,msg)
        else:
            print('Incorrect time entered!')

if __name__ == "__main__" : main()
